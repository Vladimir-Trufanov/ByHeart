bash cpplint.sh
pause